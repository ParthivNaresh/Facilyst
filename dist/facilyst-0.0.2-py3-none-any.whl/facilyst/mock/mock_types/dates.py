from facilyst.mock.mock_base import MockBase


class Dates(MockBase):
    def __init__(self):
        pass

    def create_data(self):
        self.final_output = None
