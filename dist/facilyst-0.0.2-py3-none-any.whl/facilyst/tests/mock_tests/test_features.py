from facilyst.mock import Features


def test_features():
    a = Features()
    print(a)
    assert a